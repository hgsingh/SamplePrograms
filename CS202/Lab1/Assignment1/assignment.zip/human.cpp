//@author harsukh singh cs 202 assignment 1
//derived player class
// 4/19/2015

#include "prog1.h"
using namespace std;

//default constructor 
human::human()
{
}

//default destructor
human::~human()
{
}