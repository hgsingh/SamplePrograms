//@author harsukh singh cs 202 assignment 1
//CS 202 4/15/2015
//main function

#include "prog1.h"
using namespace std;


int main()
{
    srand(time(NULL));
    game new_game;
    new_game.turn();


    //test for suit everything works here
   /* suit* new_suit = new suit("diamond");
    new_suit -> make_suit(11, 1);
    new_suit-> display_suit();*/
    //deck new_deck;
    //new_deck.shuffle();
    return 0;
}
